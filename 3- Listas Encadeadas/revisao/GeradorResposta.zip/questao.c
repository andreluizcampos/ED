//
//  questao.c
//  GeradorProvas
//
//  Created by Patricia Dockhorn Costa on 18/11/25.
//

#include "questao.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct questao{
    char* id;
    char* texto;
};

Questao* criaQuestao(char* id, char* texto){
    if (!id || !texto)
        return NULL;
    Questao* q = malloc(sizeof(Questao));
    q->id = strdup(id);
    q->texto = strdup(texto);
    return q;
}

char* retornaId(Questao* q){
    if (!q)
        return NULL;
    return q->id;
}

char* retornaTexto(Questao* q){
    if (!q)
        return NULL;
    return q->texto;
}

void liberaQuestao(Questao* q){
    if (!q)
        return;
    free(q->id);
    free(q->texto);
    free(q);
}
