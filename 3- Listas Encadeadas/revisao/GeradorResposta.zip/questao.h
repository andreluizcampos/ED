//
//  questao.h
//  GeradorProvas
//
//  Created by Patricia Dockhorn Costa on 18/11/25.
//

#ifndef questao_h
#define questao_h

#include <stdio.h>

//tipo opaco que define a questao
typedef struct questao Questao;

//cria uma questao com um id e um texto
Questao* criaQuestao(char* id, char* texto);

//retorna o ID da questao
char* retornaId(Questao* q);

//retorna o texto da questao
char* retornaTexto(Questao* q);

//libera a memoria alocada para a questao
void liberaQuestao(Questao* q);


#endif /* questao_h */
