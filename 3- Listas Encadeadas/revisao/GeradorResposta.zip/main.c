//
//  main4.c
//  Testa todas as funcionalidades! Vale ATÉ 10 pontos!
//
//  Created by Patricia Dockhorn Costa on 18/11/25.
//

#include <stdio.h>
#include "lista.h"

int main(int argc, const char * argv[]) {
    
    FILE *entrada = fopen("entrada.txt", "r");
    int qtdQuestoes;
    //lê a quantidade de questões do banco de questões
    fscanf (entrada,"%d", &qtdQuestoes);
    
    //criar uma lista geral de questões
    Lista* todas = criaLista("Todas");
    for (int i=0; i<qtdQuestoes; i++){
        char id[11];
        char enunciado[51];
        //lê o id da questão
        fscanf (entrada,"%s", id);
        //lê o enunciado da questão
        fscanf (entrada,"%50[^\n]\n", enunciado);
        //cria a questão
        Questao* q = criaQuestao(id, enunciado);
        //insere questão na lista
        insereQuestao(todas, q);
    }
    
    //agora criando a primeira prova
    char prova1[21];
    int qte = 0; //qte de questões da prova
    fscanf (entrada,"%20[^\n]\n", prova1);
    Lista* lprova1 = criaLista(prova1); //cria a lista
    
    //lê a quantidade de questões da prova
    fscanf (entrada,"%d", &qte);
    for (int i =0; i<qte; i++){
        //insere as questões pertinentes
        char id[11];
        fscanf (entrada,"%s", id);
        Questao* q = buscaQuestao(todas, id);
        //se achar a questão no banco de questões, insere na lista
        if (q)
            insereQuestao(lprova1, q);
    }
    //consome a quebra de linha
    fscanf(entrada, "%*1[\n]");
    //agora criando a segunda prova
    char prova2[21];
    int qte2 = 0; //qte de questões da prova
    fscanf (entrada,"%20[^\n]\n", prova2);
    Lista* lprova2 = criaLista(prova2);
    
    fscanf (entrada,"%d", &qte2);
    for (int i =0; i<qte2; i++){
        //insere as questões pertinentes
        char id[11];
        fscanf (entrada,"%s", id);
        Questao* q = buscaQuestao(todas, id);
        if (q)
            insereQuestao(lprova2, q);
    }
    
    imprimeProva(lprova1);
    imprimeProva(lprova2);
    
    //faz o merge das provas. Apos, prova1 e prova2 devem estar vazias
    Lista* merge = mergeProvas(lprova1, lprova2);
    
    imprimeProva(merge);

    //retira as repeticoes da prova merge
    retiraQuestoesRepetidas(merge);
    
    imprimeProva(merge);
    
    //libera as listas (prova1 e prova2 devem estar vazias neste momento)
    liberaLista(merge);
    liberaLista(lprova1);
    liberaLista(lprova2);
    
    //libera o banco de questões
    liberaListaEQuestoes(todas);
    
    return 0;
}
