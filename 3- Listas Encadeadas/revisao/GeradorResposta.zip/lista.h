//
//  lista.h
//  GeradorProvas
//
//  Created by Patricia Dockhorn Costa on 18/11/25.
//

#ifndef lista_h
#define lista_h

#include <stdio.h>
#include "questao.h"

//Tipo que define a lista de questão, ou seja, uma prova
//A prova tem um nome...
typedef struct lista Lista;

/*Cria uma lista (prova) vazia e atribui um nome
 * inputs: nome
 * output: lista inicializada e vazia
 * pre-condicao: nenhuma
 * pos-condicao: lista criada e vazia */
Lista* criaLista(char* nome);

/*Busca uma questão da lista e a retorna
 * inputs: lista de questões e o id da questão
 * output: a questão com o dado id
 * pre-condicao: lista existe (pode ser vazia ou não) e id não nulo
 * pos-condicao: lista não pode ser alterada */
Questao* buscaQuestao(Lista* lista, char* id);

/* Insere uma questão no início da lista
 * inputs: A lista e a questão a ser inserida
 * output: nenhum
 * pre-condicao: lista existe (pode ser vazia ou não) e questão q não nula
 * pos-condicao: a questão q é a primeira questão da lista */
void insereQuestao(Lista* lista, Questao* q);


/* Intercala as questões das provas 1 e 2, em uma nova lista. Por exemplo, se a prova 1 tiver questões (a1->a2->a3) e a prova 2 tiver (b1->b2->b3->b4->b5), a funcao deve retornar uma nova lista formada pelas questões (a1->b1->a2->b2->a3->b3->b4->b5). Se uma das  listas tiver mais elementos que a outra, os elementos excedentes são transferidos na mesma ordem para a nova lista. As listas originais devem ficar vazias.
 * inputs: duas listas não nulas (porém, podem estar vazias)
 * output: uma nova lista (prova), com os elementos intercalados e com o nome "merge"
 * pre-condicao: listas prova1 e prova2 nao sao NULL (mas podem estar vazias)
 * pos-condicao: lista retornada contem os elementos intercalados. As listas de entrada vazias. */
Lista* mergeProvas(Lista* prova1, Lista* prova2);


/* Retira as repeticoes na lista. Ou seja, deixa apenas uma referencia para cada questão na lista (prova), seja qual for a referencia (nao importa a ordem)
    por exemplo: q1->q2->q1->q3 pode retornar q1->q2->q3 OU q2->q1->q3
 * inputs: a lista
 * output: nenhum
 * pre-condicao: lista nao eh NULL (mas pode estar vazia)
 * pos-condicao: lista nao contem repeticoes de questões - APENAS UMA OCORRENCIA DE CADA questão */
void retiraQuestoesRepetidas(Lista* lista);


/* Imprime a lista (prova), no seguinte formato:
 Prova: "Nome da Prova"
 ID: Q5, Enunciado: Enunciado da questão 5
 ID: Q4, Enunciado: Enunciado da questão 4
 ID: Q3, Enunciado: Enunciado da questão 3
 *input: a lista
 *output: nenhum
 *pre-condicao: lista nao eh NULL (mas pode estar vazia)
 *pos-condicao: a lista nao eh alterada*/
void imprimeProva(Lista* prova);


/* Libera toda a memoria alocada para a lista(prova), mas nao pode liberar as questoes
 *input: a lista
 *output: nenhum
 *pre-condicao: lista nao eh NULL (mas pode estar vazia)
 *pos-condicao: toda a mémoria da lista liberada */
void liberaLista(Lista* prova);

/* Libera toda a memoria alocada para a lista(prova), e também para as questões
 *input: a lista
 *output: nenhum
 *pre-condicao: lista nao eh NULL (mas pode estar vazia)
 *pos-condicao: toda a memória da lista e questões liberada */
void liberaListaEQuestoes(Lista* prova);


#endif /* lista_h */
