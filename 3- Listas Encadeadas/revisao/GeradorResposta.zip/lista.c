//
//  lista.c
//  GeradorProvas
//
//  Created by Patricia Dockhorn Costa on 18/11/25.
//

#include "lista.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct celula Celula;

struct celula{
    Questao* q;
    Celula* prox;
};

struct lista{
    char* nome;
    int tam;
    Celula* prim;
    Celula* ult;
};

//retorna a quantidade de questões com o mesmo id
static int retornaQuantidade(Lista* lista, char* id){
    Celula* p;
    int cont = 0;
    
    for (p=lista->prim; p!=NULL;p=p->prox){
        if (strcmp(retornaId(p->q), id)==0)
            cont++;
    }
    return cont;
}

//busca a questão
Questao* buscaQuestao(Lista* lista, char* id){
    Celula* p;
    for (p=lista->prim; p!=NULL; p = p->prox){
        if (strcmp(retornaId(p->q), id)==0)
            return p->q;
    }
    return NULL;
}
    
    

//Libera a primeira ocorrencia da questao com o id
void retiraListaNome(Lista* lista, char* id){
    Celula* p = lista->prim;
    Celula* ant = NULL;
    
    //busca o estudante
    while (p && (strcmp(retornaId(p->q), id)!=0)){
        ant=p;
        p=p->prox;
    }
    
    //se lista vazia ou estudante não está na lista
    if (p==NULL)
        return;
    
    //se é única célula
    if (p==lista->prim && p==lista->ult){
        free(p);
        lista->prim = lista->ult = NULL;
        lista->tam--;
        return;
    }
   
    //se é primeira célula
    if (p==lista->prim){
        
        lista->prim = p->prox;
        free(p);
        lista->tam--;
        return;
    }
    
    //se é última célula
    if (p==lista->ult){
        lista->ult = ant;
        lista->ult->prox = NULL;
        free(p);
        lista->tam--;
        return;
    }
    //caso comum
    ant->prox = p->prox;
    free(p);
    lista->tam--;
}


Lista* criaLista(char* nome){
    Lista* lista = malloc(sizeof(Lista));
    lista->prim = lista->ult = NULL;
    lista->nome = strdup(nome);
    lista->tam = 0;
    
    return lista;
}

void insereQuestao(Lista* lista, Questao* q){
    Celula* nova = malloc(sizeof(Celula));
    nova->q = q;
    
    nova->prox = lista->prim;
    lista->prim = nova;
    
    if(lista->ult == NULL)
        lista->ult = nova;
    lista->tam++;
}

Lista* mergeProvas(Lista* prova1, Lista* prova2){
    
    Lista* merge = criaLista("Merge");
    
    Celula *p, *q, *pprox, *qprox;
    
    if (prova1->prim == NULL && prova2->prim == NULL)
        return merge; //retorna a lista vazia
    
    if (prova1->prim == NULL){
        merge->prim = prova2->prim;
        merge->ult = prova2->ult;
        merge->tam = prova2->tam;
        prova2->prim = prova2->ult = NULL;
        prova2->tam = 0;
        return merge;
    }
    if (prova2->prim == NULL){
        merge->prim = prova1->prim;
        merge->ult = prova1->ult;
        merge->tam = prova1->tam;
        prova1->prim = prova1->ult = NULL;
        prova1->tam = 0;
        return merge;
    }

    //vou usar como base a maior lista
    if (prova1->tam >= prova2->tam){
        merge->prim = prova1->prim;
        merge->ult = prova1->ult;
       
        p = merge->prim; pprox = p->prox;
        q = prova2->prim; qprox = q->prox;
    }else{
        merge->prim = prova2->prim;
        merge->ult = prova2->ult;
        
        q = prova1->prim; qprox = q->prox;
        p = merge->prim; pprox = p->prox;
    }
    //começando a brincadeira
    while (p && q){
        p->prox = q;
        q->prox = pprox;
        
        p = pprox;
        
        if (pprox)
            pprox = pprox->prox;
        
        q = qprox;
        
        if (qprox)
            qprox = qprox->prox;
    }
    merge->tam = prova1->tam + prova2->tam;
    prova1->prim = prova1->ult = NULL;
    prova1->tam = 0;
    prova2->prim = prova2->ult = NULL;
    prova2->tam = 0;

    return merge;
}

void retiraQuestoesRepetidas(Lista* lista){
        Celula* p = lista->prim;
        Celula* aux = NULL;
        int qte = 0;
        int entrou = 0;
        
        while (p){
            entrou = 0;
            char* id =retornaId(p->q);
            qte = retornaQuantidade(lista, id);
            while (qte>1){
                aux = p->prox;
                retiraListaNome(lista, id);
                qte = retornaQuantidade(lista, id);
                p = aux;
                entrou = 1;
            }
            if (!entrou) p=p->prox;
        }
}

void imprimeProva(Lista* prova){
    Celula* p;
    
    if (!prova)
        return;
    
    printf("Prova: %s\n", prova->nome);
    
    for (p=prova->prim; p!=NULL; p=p->prox){
        printf("ID: %s, Enunciado: %s\n", retornaId(p->q), retornaTexto(p->q));
    }
}

void liberaLista(Lista* prova){
    Celula* p = prova->prim;
    Celula* pos = p;
    
    while(p){
        pos = p->prox;
        free(p);
        p = pos;
    }
    free(prova->nome);
    free(prova);
}

void liberaListaEQuestoes(Lista* prova){
    Celula* p = prova->prim;
    Celula* pos = p;
    
    while(p){
        pos = p->prox;
        liberaQuestao(p->q);
        free(p);
        p = pos;
    }
    free(prova->nome);
    free(prova);
}
