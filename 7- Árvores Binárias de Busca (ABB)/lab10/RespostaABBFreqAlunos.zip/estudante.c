//
//  estudante.c
//  FrequenciaAlunos
//
//  Created by Patricia Dockhorn Costa on 11/12/25.
//

#include "estudante.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//definindo a estrutura do estudante
struct estudante{
    char* nome;
    int faltas;
    int presencas;
};

Estudante* criaEstudante(char* nome){
    Estudante* est = malloc(sizeof(Estudante));
    est->nome = strdup(nome);
    est->faltas = 0;
    est->presencas= 0;
    return est;
}

void incrementaPresencaFalta(Estudante* est, char f){
    if (f == 'P')
        est->presencas++;
    else if (f == 'F')
        est->faltas++;
}


void liberaEstudante(Estudante* est){
    free(est->nome);
    free(est);
}

int retornaFaltasEstudante(Estudante* est){
    return est->faltas;
}

int retornaPresencasEstudante(Estudante* est){
    return est->presencas;
}

char* retornaNomeEstudante(Estudante* est){
    return est->nome;
}
