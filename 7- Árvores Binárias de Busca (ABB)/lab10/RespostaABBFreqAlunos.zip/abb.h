//
//  abb.h
//  FrequenciaAlunos
//
//  Created by Patricia Dockhorn Costa on 11/12/25.
//

#ifndef abb_h
#define abb_h

#include <stdio.h>
#include "estudante.h"

//Tipo opaco que de define a árvore
typedef struct abb Abb;

//Insere nó na ABB (usando o nome do estudante como chave de busca)
Abb* insereAbb(Abb* raiz, char* nome);

//Atualiza a Frequência do estudante, de acordo com f (se for P, atualiza presença. Se for F, atualiza falta)
void atualizaAbb(Abb* raiz, char* nome, char f);

//Imprime a ABB no arquivo de saída, de forma crescente por nome do estudante
//usando o padrão do arquivo dado na especificação
void imprimeAbb(Abb* raiz, FILE* saida);

//libera toda a memória da árvore, inclusive dos estudantes também
void liberaAbb(Abb* raiz);


#endif /* abb_h */
