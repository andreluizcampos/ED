//
//  estudante.h
//  FrequenciaAlunos
//
//  Created by Patricia Dockhorn Costa on 11/12/25.
//

#ifndef estudante_h
#define estudante_h

#include <stdio.h>

//tipo opaco que define o estudante
typedef struct estudante Estudante;

//cria o estudante, com um dado nome
Estudante* criaEstudante(char* nome);

//incremente a frequência do estudante. Se f for P, incrementa presença. Se for F, incrementa falta.
void incrementaPresencaFalta(Estudante* est, char f);

//libero a memória alocada para o estudante
void liberaEstudante(Estudante* est);

//retorna número de faltas do estudante
int retornaFaltasEstudante(Estudante* est);

//retorna número de presenças do estudante
int retornaPresencasEstudante(Estudante* est);

//retorna o nome do estudante
char* retornaNomeEstudante(Estudante* est);

#endif /* estudante_h */
