//
//  abb.c
//  FrequenciaAlunos
//
//  Created by Patricia Dockhorn Costa on 11/12/25.
//

#include "abb.h"
#include <stdlib.h>
#include <string.h>

//definindo a árvore binária de busca SEM sentinela
struct abb{
    Estudante* est;
    Abb* esq;
    Abb* dir;
};


Abb* insereAbb(Abb* raiz, char* nome){
    //se raiz NULL, está na hora de inserir o nó
    if (!raiz){
        raiz = malloc (sizeof(Abb));
        raiz->est = criaEstudante(nome);
        raiz->esq = raiz->dir = NULL;
    }
    //acho o lugar, fazendo a busca
    else if (strcmp(retornaNomeEstudante(raiz->est), nome)>0)
        raiz->esq = insereAbb(raiz->esq, nome);
    else
        raiz->dir = insereAbb(raiz->dir, nome);
    return raiz;
}


void atualizaAbb(Abb* raiz, char* nome, char f){
    if (!raiz)
        return;
    //achei o estudante na árvore
    if (strcmp(retornaNomeEstudante(raiz->est), nome)==0){
        incrementaPresencaFalta (raiz->est, f);
        return;
    }
    //acha o estudante
    if (strcmp(retornaNomeEstudante(raiz->est), nome)>0)
        atualizaAbb(raiz->esq, nome, f);
    else
        atualizaAbb(raiz->dir, nome, f);
}

void imprimeAbb(Abb* raiz, FILE* saida){
    if (raiz){
        imprimeAbb(raiz->esq, saida);
        fprintf(saida, "%s %dP %dF\n", retornaNomeEstudante(raiz->est), retornaPresencasEstudante(raiz->est), retornaFaltasEstudante(raiz->est));
        imprimeAbb(raiz->dir, saida);
    }
}

void liberaAbb(Abb* raiz){
    if (raiz){
        liberaAbb(raiz->esq);
        liberaAbb(raiz->dir);
        liberaEstudante(raiz->est);
        free(raiz);
    }
}
