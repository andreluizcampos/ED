//
//  main.c
//  FrequenciaAlunos
//
//  Created by Patricia Dockhorn Costa on 11/12/25.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "abb.h"

int main(int argc, const char * argv[]) {
    
    //abrindo o arquivo de entrada (entrada.txt)
    FILE* entrada = fopen("entrada.txt", "r");
    //inicio a árvore sem sentinela (ponteiro da raiz começa com NULL mesmo)
    Abb* arvore = NULL;
    
    //pego os valores da primeira linha do arquivo
    char N; int arquivos;
    fscanf (entrada,"%c %d\n", &N, &arquivos);
    
    //vou ler os nomes dos estudantes para inserir na árvore
    char nome [30];
    while (fscanf (entrada,"%s \n", nome) == 1){
        arvore = insereAbb(arvore, nome);
    }
    
    //para cada um dos arquivos de presença e falta, vou abrir e atualizar as presenças
    for (int i=1; i<=arquivos;i++){
        char buffer[30];
        //formando a string com o nome do arquivo
        snprintf(buffer, sizeof(buffer),"%s%d%s", "entrada", i, ".txt");
        
        
        //abre o arquivo para leitura
        FILE* arq = fopen(buffer,"r");
        
        //para cada um dos estudantes
        char f; //para P ou F
        
        while (fscanf (arq,"%s %c\n", nome, &f) == 2){
            atualizaAbb(arvore, nome, f);
        }
        fclose(arq);
    }
    
    //abrindo arquivo de saída
    FILE* saida = fopen("saida.txt", "wt");
    imprimeAbb(arvore, saida);
    
    liberaAbb(arvore);
    
    fclose(entrada);
    fclose(saida);
     
    return 0;
}
