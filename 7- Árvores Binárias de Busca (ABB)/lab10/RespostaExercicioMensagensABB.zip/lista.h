//
//  lista.h
//  MensagensABB
//
//  Created by Patricia Dockhorn Costa on 15/12/25.
//

#ifndef lista_h
#define lista_h

#include <stdio.h>

//lista com sentinela
typedef struct lista Lista;

//cria a lista, com um dado email
Lista* criaLista(char* email);

//retorna o email da lista
char* retornaEmail(Lista* lista);

//retorna o número de mensagens da lista
int retornaNMensagens(Lista* lista);

//insere mensagem no final da lista
void insereFinal(Lista* lista, char* mensagem);

//libera toda a memória alocada, inclusive das mensagens
void liberaLista(Lista* lista);

//imprime a lista de mensagens no arquivo de saída
void imprimeLista(Lista* lista, FILE* arq);


#endif /* lista_h */
