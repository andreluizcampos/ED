//
//  abb.c
//  MensagensABB
//
//  Created by Patricia Dockhorn Costa on 15/12/25.
//

#include "abb.h"
#include <stdlib.h>
#include <string.h>

//Tipo opaco que de define a árvore, que é uma árvore de listas de mensanges
struct abb{
    Lista* lista;
    Abb* esq;
    Abb* dir;
};

//Insere nó na ABB (usando o email como chave de busca)
Abb* insereAtualizaAbb(Abb* raiz, char* email, char* mensagem){
    Lista* lista;
    //se raiz NULL, está na hora de inserir o nó
    if (!raiz){
        //cria a lista
        lista = criaLista(email);
        //insere mensagem no final
        insereFinal(lista, mensagem);
        raiz = malloc (sizeof(Abb));
        raiz->lista = lista;
        raiz->esq = raiz->dir = NULL;
    }
    //acho o lugar, fazendo a busca
    else if (strcmp(retornaEmail(raiz->lista), email)>0)
        raiz->esq = insereAtualizaAbb(raiz->esq, email, mensagem);
    else if (strcmp(retornaEmail(raiz->lista), email)<0)
        raiz->dir = insereAtualizaAbb(raiz->dir, email, mensagem);
    else{
        //achou o email, insere a mensagem na lista de mensagens
        insereFinal(raiz->lista, mensagem);
    }
    return raiz;
}

//Imprime a ABB no arquivo de saída, imprimindo a lista de mensagens por email
//usando o padrão do arquivo dado na especificação
void imprimeAbb(Abb* raiz, FILE* saida){
    if (raiz){
        imprimeAbb(raiz->esq, saida);
        imprimeLista(raiz->lista, saida);
        imprimeAbb(raiz->dir, saida);
    }
}

//libera toda a memória da árvore, inclusive das mensagens, lista, etc.
void liberaAbb(Abb* raiz){
    if (raiz){
        liberaAbb(raiz->esq);
        liberaAbb(raiz->dir);
        liberaLista(raiz->lista);
        free(raiz);
    }
}

//retorna o número de nós da árvore
int retornaNNos(Abb* raiz){
    if (!raiz)
        return 0;
    return 1 + retornaNNos(raiz->esq) + retornaNNos(raiz->dir);
}

//função que percorre a árvore e preenche o vetor com as listas
void preencheVetor(Abb* raiz, Lista** vet, int* indice){
    if (raiz){
        vet[*indice] = raiz->lista;
        (*indice)++;
        preencheVetor (raiz->esq, vet, indice);
        preencheVetor (raiz->dir, vet, indice);
    }
}

//retorna o número total de mensagens na árvore
int nTotalMensagens(Abb* raiz){
    if (!raiz)
        return 0;
    return retornaNMensagens(raiz->lista) + nTotalMensagens(raiz->esq) + nTotalMensagens(raiz->dir);
}

//dados dois nós da árvore, retorna o nó que contém o maior número de mensagens
static Abb* retornaMaior(Abb* raiz1, Abb* raiz2){
    if (!raiz1 && !raiz2)
        return NULL;
    else if (!raiz1)
        return raiz2;
    else if (!raiz2)
        return raiz1;
    else
        return (retornaNMensagens(raiz1->lista)>retornaNMensagens(raiz2->lista)) ? raiz1 : raiz2;
}

//retorna o nó com o maior número de mensagens da árvore
Abb* maiorNMensagens (Abb* raiz){
    Abb* maior;
    if (!raiz)
        return NULL;
    if (raiz->dir==NULL && raiz->esq==NULL)
        return raiz;
 
    else{
        Abb* esq = maiorNMensagens(raiz->esq);
        Abb* dir = maiorNMensagens(raiz->dir);
        maior = retornaMaior (esq, dir);
        maior = retornaMaior (maior, raiz);
    }
    return maior;
}

Lista* retornaListaNo(Abb* raiz){
    return raiz->lista;
}
