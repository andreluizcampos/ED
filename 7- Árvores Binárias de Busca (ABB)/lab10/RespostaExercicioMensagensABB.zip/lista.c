//
//  lista.c
//  MensagensABB
//
//  Created by Patricia Dockhorn Costa on 15/12/25.
//

#include "lista.h"
#include <stdlib.h>
#include <string.h>


typedef struct cel Celula;

struct cel{
    char* mensagem;
    Celula* prox;
};


struct lista{
    Celula* prim;
    Celula* ult;
    char* email;
    int nmensagens;
};

Lista* criaLista(char* email){
    Lista* lista = malloc(sizeof(Lista));
    lista->prim = lista->ult = NULL;
    lista->email = strdup(email);
    lista->nmensagens = 0;
    return lista;
}

char* retornaEmail(Lista* lista){
    return lista->email;
}
int retornaNMensagens(Lista* lista){
    return lista->nmensagens;
}

void insereFinal(Lista* lista, char* mensagem){
    Celula* nova = malloc(sizeof(Celula));
    nova->mensagem = strdup(mensagem);
    nova->prox = NULL;
    lista->nmensagens++;
    
    //lista vazia
    if (lista->prim == NULL)
        lista->prim = lista->ult = nova;
    else{
        lista->ult->prox = nova;
        lista->ult = nova;
    }
}

void liberaLista(Lista* lista){
    Celula* p = lista->prim;
    
    while(p){
        Celula* t = p->prox;
        free(p->mensagem);
        free(p);
        p = t;
    }
    free(lista->email);
    free(lista);
}

void imprimeLista(Lista* lista, FILE* arq){
    Celula* p = lista->prim;
    if (!lista)
        return;
    fprintf(arq, "%s\n", lista->email);
    while (p){
        fprintf(arq, "     %s\n", p->mensagem);
        p = p->prox;
    }
}
