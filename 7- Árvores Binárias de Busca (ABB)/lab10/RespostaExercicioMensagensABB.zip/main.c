//
//  main.c
//  MensagensABB
//
//  Created by Patricia Dockhorn Costa on 15/12/25.
//

#include <stdio.h>
#include "abb.h"
#include <stdlib.h>

//callback de comparação (compara por número de mensagens)
int compara (const void* p1, const void* p2){
    Lista** lista1 = (Lista**) p1;
    Lista** lista2 = (Lista**) p2;
    
    if (retornaNMensagens(*lista1)<retornaNMensagens(*lista2))
        return -1;
    else if(retornaNMensagens(*lista1)>retornaNMensagens(*lista2))
        return 1;
    else
        return 0;
}

//====================================

int main(int argc, const char * argv[]) {
    // Buffer para lida do arquivo de entrada
    FILE *f_in = fopen("./entrada.txt", "r");
    char bufferEmail[300], bufferMensagem[300];
 
    Abb* arvore = NULL;

    while(fscanf(f_in, "%s %[^\n]\n", bufferEmail, bufferMensagem) == 2) {
        arvore = insereAtualizaAbb(arvore, bufferEmail, bufferMensagem);
    }

    // Gerando arquivo de saída
    FILE *f_out = fopen("saida.txt", "w");
    
    //retorna número de nós da árvore
    int tamanho = retornaNNos(arvore);
    //cria vetor para ordenar por número de mensagens
    Lista** vet = malloc(sizeof(Lista*)*tamanho);
    
    int indice = 0;
    //preenche o vetor com as listas
    preencheVetor(arvore, vet, &indice);
    
    //vou usar a quick para ordenar por número de mensagens
    qsort(vet, tamanho, sizeof(Lista*), compara);
    
    
    //vou imprimir todas as listas de mensagens do vetor já ordenado por número de mensagens
    for (int i = 0; i<tamanho; i++){
        imprimeLista(vet[i], f_out);
    }
 
   // imprimeAbb(arvore, f_out);
    
    fprintf(f_out, "--------------------------\n");
    
    fprintf(f_out, "Número total de usuários: %d\n", tamanho);
    fprintf(f_out, "Número total de mensagens: %d\n", nTotalMensagens(arvore));
    
    //pega o nó com o maior número de mensagens na árvore
    Abb* maior = maiorNMensagens (arvore);
    fprintf(f_out, "Usuario com maior número de mensagens : %s\n", retornaEmail(retornaListaNo(maior)));
    
    
    liberaAbb(arvore);
    
    //libera o vetor
    free(vet);
    
    fclose(f_in);
    fclose(f_out);
 
    return 0;
}
