//
//  abb.h
//  MensagensABB
//
//  Created by Patricia Dockhorn Costa on 15/12/25.
//

#ifndef abb_h
#define abb_h

#include <stdio.h>
#include "lista.h"

//Tipo opaco que de define a árvore
typedef struct abb Abb;

//Insere um nó na ABB (usando o email como chave de busca) - caso ainda não exista na árvore
//Caso o email já exista, apenas atualiza, inserindo a mensagem na lista
Abb* insereAtualizaAbb(Abb* raiz, char* email, char* mensagem);

//Imprime a ABB no arquivo de saída, de forma crescente por email
//usando o padrão do arquivo dado na especificação
void imprimeAbb(Abb* raiz, FILE* saida);

//libera toda a memória da árvore, inclusive das mensagens, lista, etc.
void liberaAbb(Abb* raiz);

//retorna o número de nós da árvore
int retornaNNos(Abb* raiz);

//preenche o vetor com as listas da árvore
void preencheVetor(Abb* raiz, Lista** vet, int* indice);

//retorna o número total de mensagens da árvore
int nTotalMensagens(Abb* raiz);

//retorna a lista de mensagens de um dado nó
Lista* retornaListaNo(Abb* raiz);

//retorna o nó com o maior número de mensagens da árvore
Abb* maiorNMensagens (Abb* raiz);

#endif /* abb_h */
